import "./styles.css";
import { useState } from "react";

const App = () => {
  const [fname, setFname] = useState("");
  const [lname, setLname] = useState("");
  const [email, setEmail] = useState("");
  const [add, setAdd] = useState("");
  const [edit, setEdit] = useState(false);

  return (
    <>
      {!edit ? (
        <div className="center">
          <div className="heading">
            <h1>Profile Page</h1>
          </div>
          <h2>First Name : {fname}</h2>
          <h2>Last Name : {lname}</h2>
          <h2>Email : {email}</h2>
          <h2>Address : {add}</h2>
        </div>
      ) : (
        <form action="">
          <div className="center">
            <h1>First Name - </h1>
            <input
              type="text"
              value={fname}
              onChange={(e) => setFname(e.target.value)}
            />
            <h1>Last Name - </h1>
            <input
              type="text"
              value={lname}
              onChange={(e) => setLname(e.target.value)}
            />
            <h1>Email - </h1>
            <input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <h1>Address - </h1>
            <input
              type="text"
              value={add}
              onChange={(e) => setAdd(e.target.value)}
            />
          </div>
        </form>
      )}
      <br />
      <div className="button">
        <button type="submit" onClick={() => setEdit(!edit)}>
          {edit ? "Update Profile" : "Edit"}
        </button>
      </div>
    </>
  );
};
export default App;